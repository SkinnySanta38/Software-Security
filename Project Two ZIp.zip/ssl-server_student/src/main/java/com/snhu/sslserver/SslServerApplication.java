package com.snhu.sslserver;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Duration;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import io.github.bucket4j.*;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}
}
	@RestController
	class ServerController {
		private final Bucket bucket;
		public ServerController() {
		Bandwidth limit = Bandwidth.classic(20, Refill.greedy(20, Duration.ofMinutes(1)));
		bucket = Bucket.builder().addLimit(limit).build();
	}

	@RequestMapping(value = "/hash")
	public String myHash() throws NoSuchAlgorithmException {
		if(bucket.tryConsume(1)) {
			String data = "Hello World Check Sum!";
			String checksum = getSHA(data);
			return "<p>Data: " + data + "<p>Checksum: " + checksum;
		}
			return "Error too many requests";
	}

	// Maps a route for the home page
	@RequestMapping(value = "/")
	final public String mainPage() {
		final String message = "Main Page <br> <a href=\"./hash\">File Checksum</a> ";

		return message;
	}

	// Converts a string into a secure hash using SHA-512/256
	private final static String getSHA(String data) throws NoSuchAlgorithmException {
		MessageDigest md;

		md = MessageDigest.getInstance("SHA-512/256");
		md.update(data.getBytes());
		byte[] byteHash = md.digest();
		String hash = byteToHex(byteHash);
		return hash;
	}

	// Converts a byte array into a hexadecimal string
	private static String byteToHex(byte[] bytes) {
		final char[] HEX_ARRAY = "0123456789ABCDEF".toCharArray();
		char[] hexChars = new char[bytes.length * 2];
		for (int j = 0; j < bytes.length; j++) {
			int v = bytes[j] & 0xFF;
			hexChars[j * 2] = HEX_ARRAY[v >>> 4];
			hexChars[j * 2 + 1] = HEX_ARRAY[v & 0x0F];
		}
		return new String(hexChars);
	}
	
	@Controller
	public class ErrController implements ErrorController  {

	    @RequestMapping("/error")
	    public String handleError() {
	        return "Error";
	    }

		@Override
		public String getErrorPath() {
			return "/error";
		}
	}
	
	@Configuration
	@EnableWebSecurity
	public class SecurityConfig {
		
		public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
			http
				.authorizeRequests()
				.antMatchers(HttpMethod.GET, "/login");
			return http.build();
		}
		
		@Bean
		public UserDetailsService userDetailsService() {
			UserDetails user =
				 User.withUsername("user1")
		            .password(passwordEncoder().encode("user1Pass"))
					.roles("USER")
					.build();
			return new InMemoryUserDetailsManager(user);
		}
		
		@Bean 
		public PasswordEncoder passwordEncoder() { 
		    return new BCryptPasswordEncoder(); 
		}
	}
}